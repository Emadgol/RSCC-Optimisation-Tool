RSCC GUI H-GB — corrected build (2026-10-19)

Place RSCC_GUI_HGB_Corrected.py in your RSCC-GUI folder, alongside:
  models/model_config.json
  models/ols_model.pkl         (copy of Full_Run/Models/Hybrid_GB_OLS.pkl)
  models/gb_residual_model.pkl (copy of Full_Run/Models/Hybrid_GB_ML.pkl)
  data/DecisionVarDatabase.xlsx (needed when Mahalanobis is checked)
  outputs/ (automatically created)

The model_config.json must contain:
{
  "model_name": "H-GB",
  "ols_file": "ols_model.pkl",
  "residual_file": "gb_residual_model.pkl",
  "feature_names": ["B","SFR","FAR","SR","1/W/B","BCI","LPR","CAR","RFAR","RCAR","SPR","Ln(1+TA)"]
}

Run in a terminal: python RSCC_GUI_HGB_Corrected.py
Or use the accompanying notebook inside the RSCC-GUI directory.

Packages: numpy, pandas, joblib, scikit-learn, pymoo, matplotlib, openpyxl, tkinter.

This patch fixes sklearn feature-name warnings by passing NumPy arrays, validates
model dimensionality and preserves the prior GUI structure. It writes detailed
errors to outputs/RSCC_GUI_Error_Log.txt rather than displaying long tracebacks.

RESEARCH WARNING: Optimization constraint equations and the 12-feature engineering
(including BCI) must be independently checked against the final published
optimization methodology. This build does not certify research validity.
