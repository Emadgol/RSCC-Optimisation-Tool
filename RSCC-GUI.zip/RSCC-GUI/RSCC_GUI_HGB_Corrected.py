"""RSCC GUI: H-GB hybrid (OLS + Gradient Boosting residual) NSGA-II.
IMPORTANT: review model artefact names, preprocessing and constraints against the
FINAL research optimisation notebook before using results in a publication.
"""
from pathlib import Path
import json, threading, queue, traceback, re, math, datetime
import numpy as np
import pandas as pd
import joblib
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import matplotlib
matplotlib.use('TkAgg')
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from pymoo.core.problem import Problem
from pymoo.core.callback import Callback
from pymoo.core.population import Population
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.optimize import minimize

try:
    HERE = Path(__file__).resolve().parent
except NameError:
    HERE = Path.cwd()  # Jupyter: notebook working directory
FEATURES = ['B','SFR','FAR','SR','1/W/B','BCI','LPR','CAR','RFAR','RCAR','SPR','Ln(1+TA)']
DECISIONS = ['C','SF','FA','Sl','LP','W','SP','r_fine','r_rca','r_rfa']
MATERIALS = [('C','Cement',280,470,.22,.9,3150),('SF','Silica Fume',0,80,.9,.03,2200),
 ('FA','Fly Ash',0,350,.04,.015,2300),('Sl','Slag',0,300,.1,.07,2900),
 ('LP','Limestone Powder',0,180,.04,.015,2700),('NCA','Natural Coarse Aggregate',480,1200,.025,.007,2650),
 ('NFA','Natural Fine Aggregate',550,1150,.022,.006,2600),('RCA','Recycled Coarse Aggregate',0,1200,.018,.004,2400),
 ('RFA','Recycled Fine Aggregate',0,977,.015,.003,2300),('W','Water',140,210,.001,.0003,1000),
 ('SP','Superplasticiser',2,8,4.,2.5,1050)]
RATIOS = [('W/B',.25,.5),('W/C',.3,1.),('SP/B',.003,.02),('SF/B',0,.15),
 ('FA/B',0,.6),('S/B',0,.7),('TFA/B',1,2.5),('TFA/TA',.4,.65),('LP/P',0,.3)]

class HybridPredictor:
    def __init__(self, folder):
        folder=Path(folder)
        config_file=folder/'model_config.json'
        if not config_file.exists():
            raise FileNotFoundError('Missing model_config.json in '+str(folder))
        cfg=json.loads(config_file.read_text(encoding='utf-8'))
        if cfg.get('model_name')!='H-GB':
            raise ValueError('model_config.json must explicitly specify model_name: H-GB')
        if cfg.get('feature_names')!=FEATURES:
            raise ValueError('Feature order in model_config.json does not match GUI features. Check training pipeline.')
        self.ols=joblib.load(folder/cfg['ols_file'])
        self.gb=joblib.load(folder/cfg['residual_file'])
        self.cfg=cfg
        # Fail early if a model file is incompatible with the saved training pipeline.
        for name, model in (("OLS", self.ols), ("GB residual", self.gb)):
            if not hasattr(model, 'predict'):
                raise TypeError(f'{name} file does not contain a fitted predictor')
            if hasattr(model, 'n_features_in_') and int(model.n_features_in_) != len(FEATURES):
                raise ValueError(f'{name} file expects {model.n_features_in_} features')
    def predict(self, features):
        # Both estimators were fitted on NumPy arrays in the original training script.
        # Never pass a named DataFrame to these fitted sklearn estimators.
        X = np.asarray(features, dtype=np.float64)
        if X.ndim == 1:
            X = X.reshape(1, -1)
        if X.ndim != 2 or X.shape[1] != len(FEATURES):
            raise ValueError(f"Expected {len(FEATURES)} features in the original training order")
        if not np.isfinite(X).all():
            raise ValueError("Non-finite predictor input")
        for name, model in (("OLS", self.ols), ("GB residual", self.gb)):
            n = getattr(model, "n_features_in_", None)
            if n is not None and int(n) != len(FEATURES):
                raise ValueError(f"{name} model expects {n} features, not {len(FEATURES)}")
            stored_names = getattr(model, "feature_names_in_", None)
            if stored_names is not None and list(stored_names) != FEATURES:
                raise ValueError(f"{name} stored feature order differs from model_config.json")
        ols_prediction = np.asarray(self.ols.predict(X), dtype=float).reshape(-1)
        residual_prediction = np.asarray(self.gb.predict(X), dtype=float).reshape(-1)
        result = ols_prediction + residual_prediction
        if len(result) != len(X) or not np.isfinite(result).all():
            raise ValueError("Invalid hybrid prediction")
        return float(result[0]) if len(result) == 1 else result

def calculate(x, props, predictor, mean, inv_cov, settings):
    C,SF,FA,Sl,LP,W,SP,r_fine,r_rca,r_rfa=map(float,x)
    rho=props['density']; cost_unit=props['cost']; co2_unit=props['co2']
    B=C+SF+FA+Sl; SCM=SF+FA+Sl; powder=B+LP
    if min(B,C,W,powder)<=0: raise ValueError('Nonpositive binder, cement, water or powder')
    vol_powder=sum(v/rho[k] for k,v in [('C',C),('SF',SF),('FA',FA),('Sl',Sl),('LP',LP)])
    vw=W/rho['W']; vsp=SP/rho['SP']; vagg=1-(vol_powder+vw+vsp+.02)
    if vagg<=0: raise ValueError('Nonpositive aggregate volume')
    vf=vagg*r_fine; vc=vagg*(1-r_fine)
    masses=dict(C=C,SF=SF,FA=FA,Sl=Sl,LP=LP,W=W,SP=SP,
      NCA=vc*(1-r_rca)*rho['NCA'],RCA=vc*r_rca*rho['RCA'],
      NFA=vf*(1-r_rfa)*rho['NFA'],RFA=vf*r_rfa*rho['RFA'])
    NCA,NFA,RCA,RFA=[masses[k] for k in ('NCA','NFA','RCA','RFA')]
    TFA=NFA+RFA; TA=NCA+RCA+TFA
    bci=(.6*SF+5.4*FA+40.1*Sl)/(94.1*SF+80.8*FA+89.4*Sl) if SCM>0 else 0
    feats=[B,SF/B,FA/B,Sl/B,B/W,bci,LP/powder,(NCA+RCA)/TA,RFA/TFA,RCA/(NCA+RCA),SP/B,np.log1p(settings['age'])]
    cs=predictor.predict(feats)
    f=np.array([sum(masses[k]*cost_unit[k] for k in masses),sum(masses[k]*co2_unit[k] for k in masses),-cs])
    ratios=dict(zip([k for k,_,_ in RATIOS],[W/B,W/C,SP/B,SF/B,FA/B,Sl/B,TFA/B,TFA/TA,LP/powder]))
    constraints=[]
    def bound(value,lo,hi): constraints.extend([value-hi,lo-value])
    bound(B,350,650);bound(SCM,0,300)
    for k,(lo,hi) in props['ratios'].items(): bound(ratios[k],lo,hi)
    bound(vol_powder+vw+vsp,.30,.45)
    bound(vol_powder,.14,.24)
    bound(vagg,.50,.72)
    bound(vf,.25,.42)
    bound(vc,.20,.38)
    for k in ('NCA','NFA','RCA','RFA'):bound(masses[k],*props['bounds'][k])
    if settings['use_mahalanobis']:
        diff=np.asarray(x)-mean
        dist=float(np.sqrt(max(0,diff@inv_cov@diff)))
        constraints.append(dist-settings['mahalanobis_threshold'])
    if settings['use_strength_heuristic']:
        limit=.50 if cs<=35 else .45 if cs<=45 else .40 if cs<=55 else .36 if cs<=65 else .33 if cs<=75 else .30
        constraints.append(W/B-limit)
    if settings['use_marginal_domain']:
        # This is decision-variable marginal domain; feature-space domain is NOT inferred.
        for i,k in enumerate(DECISIONS):
            lo,hi=props['decision_bounds'][k]
            bound(float(x[i]),lo,hi)
    if settings['cs_min'] is not None:constraints.append(settings['cs_min']-cs)
    if settings['cs_max'] is not None:constraints.append(cs-settings['cs_max'])
    return f,np.asarray(constraints,dtype=float),masses,ratios

def sample_physical_mix(rng, rho):
    """Volume-based proposal inspired by original GUI sampler; final G checks all constraints."""
    for _ in range(100):
        vpws=rng.uniform(.30,.45);vw=rng.uniform(.15,.23);vsp=rng.uniform(.001,.008)
        vp=vpws-vw-vsp
        if not .14<=vp<=.24:continue
        vlp=rng.uniform(0,min(.08,vp));vb=vp-vlp
        if not .12<=vb<=.23:continue
        vc=vb*rng.uniform(.4,.8);vscm=vb-vc
        weights=rng.dirichlet([1,1,1]);vsf,vfa,vsl=vscm*weights
        if vsf>.04 or vfa>.17 or vsl>.12:continue
        return np.array([vc*rho['C'],vsf*rho['SF'],vfa*rho['FA'],vsl*rho['Sl'],
                         vlp*rho['LP'],vw*rho['W'],vsp*rho['SP'],
                         rng.uniform(.45,.60),rng.uniform(0,1),rng.uniform(0,1)])
    return None

class RSCCProblem(Problem):
    def __init__(self,props,predictor,mean,inv_cov,settings):
        self.props,self.predictor,self.mean,self.inv_cov,self.settings=props,predictor,mean,inv_cov,settings
        xl=np.array([props['decision_bounds'][k][0] for k in DECISIONS],float)
        xu=np.array([props['decision_bounds'][k][1] for k in DECISIONS],float)
        if np.any(xl>=xu):raise ValueError('Decision-variable upper bounds must exceed lower bounds')
        dummy=(xl+xu)/2
        try:_,g,_,_=calculate(dummy,props,predictor,mean,inv_cov,settings)
        except ValueError:
            # Count independent of candidate feasibility.
            ng=4+2*len(RATIOS)+6+8+int(settings['use_mahalanobis'])+int(settings['use_strength_heuristic'])+20*int(settings['use_marginal_domain'])+int(settings['cs_min'] is not None)+int(settings['cs_max'] is not None)
        else:ng=len(g)
        super().__init__(n_var=10,n_obj=3,n_ieq_constr=ng,xl=xl,xu=xu)
    def _evaluate(self,X,out,*args,**kwargs):
        F=[];G=[]
        for x in np.atleast_2d(X):
            try:
                f,g,_,_=calculate(x,self.props,self.predictor,self.mean,self.inv_cov,self.settings)
                if len(g)!=self.n_ieq_constr:raise RuntimeError('Constraint count mismatch')
            except ValueError:
                f=np.array([1e12,1e12,1e12]);g=np.full(self.n_ieq_constr,1e6)
            F.append(f);G.append(g)
        out['F']=np.asarray(F);out['G']=np.asarray(G)

class Stopper(Callback):
    def __init__(self,event,updates):super().__init__();self.event=event;self.updates=updates
    def notify(self,algorithm):
        if algorithm.n_gen%10==0:self.updates.put(('progress',algorithm.n_gen))
        if self.event.is_set():algorithm.termination.force_termination=True

class GUI:
    def __init__(self,root):
        self.root=root;root.title('RSCC Optimisation Tool — H-GB Hybrid')
        self.events=queue.Queue();self.stop_event=threading.Event();self.running=False
        self._build();root.after(150,self._poll)
    def _build(self):
        # The original GUI used a broad materials column and compact control strip.
        # Preserve that arrangement and let the right-hand plots/table grow.
        style = ttk.Style(self.root)
        style.configure('RSCC.TLabelframe.Label', font=('Arial', 10, 'bold'))
        style.configure('RSCC.TButton', padding=(8, 3))
        self.root.minsize(1320, 860)
        screen_h = self.root.winfo_screenheight()
        self.root.geometry(f'1450x{min(1050, max(860, screen_h - 85))}')

        main = ttk.Frame(self.root, padding=8)
        main.pack(fill='both', expand=True)
        main.columnconfigure(0, minsize=620, weight=0)
        main.columnconfigure(1, weight=1)
        main.rowconfigure(0, weight=0, minsize=145)
        main.rowconfigure(1, weight=3, minsize=405)
        main.rowconfigure(2, weight=2, minsize=300)

        # Row 0: settings left, controls right (like the legacy interface).
        top = ttk.LabelFrame(main, text='Optimisation Settings', padding=7, style='RSCC.TLabelframe')
        top.grid(row=0, column=0, sticky='ew', padx=(0, 8), pady=(0, 7))
        self.fields = {}
        specs = [('Population size', '200'), ('Generations', '1000'), ('Seed', '42'),
                 ('Age (days)', '28'), ('Minimum CS (MPa)', ''), ('Maximum CS (MPa)', ''),
                 ('Mahalanobis threshold', '4.5')]
        for i, (name, default) in enumerate(specs):
            r, c = divmod(i, 4)
            ttk.Label(top, text=name).grid(row=r * 2, column=c, sticky='w', padx=4, pady=(1, 0))
            var = tk.StringVar(value=default)
            self.fields[name] = var
            ttk.Entry(top, textvariable=var, width=17).grid(row=r * 2 + 1, column=c,
                                                            sticky='ew', padx=4, pady=(0, 4))
        for c in range(4):
            top.columnconfigure(c, weight=1)
        self.flags = {}
        for i, (name, enabled) in enumerate([
            ('Mahalanobis', True), ('Strength heuristic', True),
            ('Marginal decision domain', True)
        ]):
            var = tk.BooleanVar(value=enabled)
            self.flags[name] = var
            ttk.Checkbutton(top, text=name, variable=var).grid(row=4, column=i,
                                                                 sticky='w', padx=4, pady=(4, 1))

        controls = ttk.LabelFrame(main, text='Controls', padding=8, style='RSCC.TLabelframe')
        controls.grid(row=0, column=1, sticky='nsew', pady=(0, 7))
        button_row = ttk.Frame(controls)
        button_row.pack(anchor='center', pady=(2, 4))
        for name, fn in [('Run', self.run), ('Stop', self.stop), ('Reset', self.reset_plot)]:
            ttk.Button(button_row, text=name, command=fn, width=16,
                       style='RSCC.TButton').pack(side='left', padx=12)
        # Status is internal; no Ready/Model text is displayed in Controls.
        self.status = tk.StringVar(value='')

        # Shared 3x2 parent grid ensures exact row-edge alignment.
        materials = ttk.LabelFrame(main, text='Material Parameters', padding=5,
                                   style='RSCC.TLabelframe')
        materials.grid(row=1, column=0, sticky='nsew', padx=(0, 8), pady=(0, 7))
        headings = ['Ingredients', 'Lower Bound\n(kg/m³)', 'Upper Bound\n(kg/m³)',
                    'Unit Price\n(AUD/kg)', 'Unit CO₂\n(kg-eq/kg)', 'Density\n(kg/m³)']
        for j, heading in enumerate(headings):
            ttk.Label(materials, text=heading, justify='center', anchor='center').grid(
                row=0, column=j, padx=3, pady=(1, 5), sticky='ew')
        materials.columnconfigure(0, minsize=168, weight=1)
        for j in range(1, 6):
            materials.columnconfigure(j, minsize=79, weight=1)
        self.material_vars = {}
        for i, (key, name, lo, hi, price, co2, density) in enumerate(MATERIALS, 1):
            ttk.Label(materials, text=name).grid(row=i, column=0, sticky='w', padx=3, pady=2)
            variables = []
            for j, value in enumerate([lo, hi, price, co2, density], 1):
                var = tk.StringVar(value=str(value))
                ttk.Entry(materials, textvariable=var, width=10).grid(
                    row=i, column=j, sticky='ew', padx=3, pady=2)
                variables.append(var)
            self.material_vars[key] = variables

        ratios = ttk.LabelFrame(main, text='Critical Ratio Bounds', padding=6,
                                style='RSCC.TLabelframe')
        ratios.grid(row=2, column=0, sticky='nsew', padx=(0, 8))
        for j, heading in enumerate(['Ratios', 'Lower Bound', 'Upper Bound']):
            ttk.Label(ratios, text=heading).grid(row=0, column=j, sticky='w', padx=6, pady=4)
        ratios.columnconfigure(0, minsize=180)
        ratios.columnconfigure(1, minsize=135)
        ratios.columnconfigure(2, minsize=135)
        self.ratio_vars = {}
        for i, (key, lo, hi) in enumerate(RATIOS, 1):
            ttk.Label(ratios, text=key).grid(row=i, column=0, sticky='w', padx=6, pady=2)
            v1, v2 = tk.StringVar(value=str(lo)), tk.StringVar(value=str(hi))
            ttk.Entry(ratios, textvariable=v1, width=18).grid(row=i, column=1, sticky='w', padx=6, pady=2)
            ttk.Entry(ratios, textvariable=v2, width=18).grid(row=i, column=2, sticky='w', padx=6, pady=2)
            self.ratio_vars[key] = (v1, v2)

        # Right column, aligned exactly with materials and ratio bounds.
        plot_frame = ttk.LabelFrame(main, text='Optimal RSCC Mix 3D Plot', padding=2,
                                    style='RSCC.TLabelframe')
        plot_frame.grid(row=1, column=1, sticky='nsew', pady=(0, 7))
        self.fig = Figure(figsize=(7.2, 4.1), dpi=100, facecolor='white')
        self.ax = self.fig.add_subplot(111, projection='3d')
        self.fig.subplots_adjust(left=0.11, right=0.88, bottom=0.11, top=0.95)
        self.canvas = FigureCanvasTkAgg(self.fig, master=plot_frame)
        self.canvas.get_tk_widget().pack(fill='both', expand=True)

        table_frame = ttk.LabelFrame(main, text='Optimal RSCC Mixes', padding=4,
                                     style='RSCC.TLabelframe')
        table_frame.grid(row=2, column=1, sticky='nsew')
        self.table_columns = ['C', 'SF', 'FA', 'Sl', 'LP', 'W', 'SP',
                              'NCA', 'NFA', 'RCA', 'RFA',
                              'Cost (AUD/m³)', 'CO2 (kg/m³)', 'CS (MPa)']
        # Windows ttk headings often clip the second line. Build an explicit
        # two-line header above the Treeview and scroll it with the data rows.
        headings = {'C':'Cement', 'SF':'Silica Fume', 'FA':'Fly Ash',
                    'Sl':'Slag', 'LP':'Limestone Powder', 'W':'Water',
                    'SP':'Superplasticiser', 'NCA':'Natural Coarse Aggregate',
                    'NFA':'Natural Fine Aggregate', 'RCA':'Recycled Coarse Aggregate',
                    'RFA':'Recycled Fine Aggregate'}
        self.column_widths = {key:(145 if key in headings else 125)
                              for key in self.table_columns}
        self.tree = ttk.Treeview(table_frame, columns=self.table_columns,
                                 show='', height=8)
        for key in self.table_columns:
            self.tree.column(key, width=self.column_widths[key], minwidth=self.column_widths[key],
                             anchor='center', stretch=False)
        header = tk.Canvas(table_frame, height=72, highlightthickness=0,
                           bg='#f5f5f5', bd=0)
        header_inner = ttk.Frame(header)
        header.create_window((0, 0), window=header_inner, anchor='nw')
        for j, key in enumerate(self.table_columns):
            label = headings.get(key, key)
            unit = '(kg/m³)' if key in headings else ''
            if key == 'Cost (AUD/m³)': label, unit = 'Cost', '(AUD/m³)'
            if key == 'CO2 (kg/m³)': label, unit = 'CO₂', '(kg/m³)'
            if key == 'CS (MPa)': label, unit = 'CS', '(MPa)'
            cell = ttk.Frame(header_inner, width=self.column_widths[key], height=70,
                             relief='solid', borderwidth=1)
            cell.grid(row=0, column=j, sticky='nsew')
            cell.grid_propagate(False)
            ttk.Label(cell, text=label, anchor='center', justify='center',
                      wraplength=self.column_widths[key]-8).pack(fill='x', pady=(2,0))
            ttk.Label(cell, text=unit, anchor='center', justify='center').pack(fill='x')
        header_inner.update_idletasks()
        header.configure(scrollregion=(0, 0, sum(self.column_widths.values()), 72))
        def horizontal_scroll(*args):
            self.tree.xview(*args)
            header.xview(*args)
        def sync_header(first, last):
            xbar.set(first, last)
            header.xview_moveto(first)
        ybar = ttk.Scrollbar(table_frame, orient='vertical', command=self.tree.yview)
        xbar = ttk.Scrollbar(table_frame, orient='horizontal', command=horizontal_scroll)
        self.tree.configure(yscrollcommand=ybar.set, xscrollcommand=sync_header)
        header.grid(row=0, column=0, sticky='ew')
        self.tree.grid(row=1, column=0, sticky='nsew')
        ybar.grid(row=1, column=1, sticky='ns')
        xbar.grid(row=2, column=0, sticky='ew')
        table_frame.columnconfigure(0, weight=1)
        table_frame.rowconfigure(1, weight=1)
        self.reset_plot()
    @staticmethod
    def _number(value, label, *, integer=False, optional=False, minimum=None,
                strictly_positive=False):
        raw = str(value)
        if optional and raw == '':
            return None
        # Reject blank strings, spaces, comma decimals, NaN, Inf and text.
        pattern = r'[+-]?\d+' if integer else r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?'
        if not re.fullmatch(pattern, raw, flags=re.ASCII):
            raise ValueError(f'{label}: enter a valid numeric value without spaces or letters.')
        number = int(raw) if integer else float(raw)
        if not math.isfinite(number):
            raise ValueError(f'{label}: value must be finite.')
        if strictly_positive and number <= 0:
            raise ValueError(f'{label}: value must be greater than zero.')
        if minimum is not None and number < minimum:
            raise ValueError(f'{label}: value must be at least {minimum}.')
        return number

    def _inputs(self):
        parse = self._number
        props = {'bounds':{}, 'density':{}, 'cost':{}, 'co2':{}, 'ratios':{}}
        for key, name, *_ in MATERIALS:
            entries = self.material_vars[key]
            lo = parse(entries[0].get(), f'{name} lower bound', minimum=0)
            hi = parse(entries[1].get(), f'{name} upper bound', minimum=0)
            price = parse(entries[2].get(), f'{name} unit price', minimum=0)
            co2 = parse(entries[3].get(), f'{name} unit CO2', minimum=0)
            density = parse(entries[4].get(), f'{name} density', strictly_positive=True)
            if lo > hi:
                raise ValueError(f'{name}: lower bound ({lo}) cannot exceed upper bound ({hi}).')
            if key in ('C','SF','FA','Sl','LP','W','SP') and lo == hi:
                raise ValueError(f'{name}: decision-variable upper bound must be greater than lower bound.')
            props['bounds'][key] = (lo,hi)
            props['density'][key] = density
            props['cost'][key] = price
            props['co2'][key] = co2
        for key, entries in self.ratio_vars.items():
            lo = parse(entries[0].get(), f'{key} lower bound', minimum=0)
            hi = parse(entries[1].get(), f'{key} upper bound', minimum=0)
            if lo > hi:
                raise ValueError(f'{key}: lower bound ({lo}) cannot exceed upper bound ({hi}).')
            if key in ('W/B','W/C','SF/B','FA/B','S/B','LP/P','TFA/TA') and hi > 1:
                raise ValueError(f'{key}: upper bound cannot exceed 1 for this ratio.')
            props['ratios'][key] = (lo,hi)
        props['decision_bounds'] = {k:props['bounds'][k] for k in ['C','SF','FA','Sl','LP','W','SP']}
        props['decision_bounds'].update({'r_fine':(.45,.60),'r_rca':(0,1),'r_rfa':(0,1)})
        pop = parse(self.fields['Population size'].get(), 'Population size', integer=True, minimum=4)
        gens = parse(self.fields['Generations'].get(), 'Generations', integer=True, minimum=1)
        seed = parse(self.fields['Seed'].get(), 'Seed', integer=True, minimum=0)
        age = parse(self.fields['Age (days)'].get(), 'Age (days)', strictly_positive=True)
        threshold = parse(self.fields['Mahalanobis threshold'].get(), 'Mahalanobis threshold', strictly_positive=True)
        cs_min = parse(self.fields['Minimum CS (MPa)'].get(), 'Minimum CS (MPa)', optional=True, minimum=0)
        cs_max = parse(self.fields['Maximum CS (MPa)'].get(), 'Maximum CS (MPa)', optional=True, strictly_positive=True)
        if cs_min is not None and cs_max is not None and cs_min > cs_max:
            raise ValueError(f'Minimum CS ({cs_min} MPa) cannot exceed Maximum CS ({cs_max} MPa).')
        settings = {'age':age, 'use_mahalanobis':self.flags['Mahalanobis'].get(),
                    'mahalanobis_threshold':threshold,
                    'use_strength_heuristic':self.flags['Strength heuristic'].get(),
                    'use_marginal_domain':self.flags['Marginal decision domain'].get(),
                    'cs_min':cs_min, 'cs_max':cs_max}
        return props,settings,pop,gens,seed

    def run(self):
        if self.running:return
        try:args=self._inputs()
        except Exception as exc:messagebox.showerror('Invalid settings',str(exc));return
        self.stop_event.clear();self.running=True;self.status.set('Loading model and checking inputs...')
        threading.Thread(target=self._worker,args=args,daemon=True).start()
    def _worker(self,props,settings,pop,gens,seed):
        try:
            predictor=HybridPredictor(HERE/'models')
            if settings['use_mahalanobis']:
                db=HERE/'data'/'DecisionVarDatabase.xlsx'
                if not db.is_file():raise FileNotFoundError('Mahalanobis enabled: missing '+str(db))
                df=pd.read_excel(db)
                if all(k in df.columns for k in DECISIONS):X=df[DECISIONS].to_numpy(float)
                elif df.shape[1]==10:X=df.to_numpy(float)
                else:raise ValueError('DecisionVarDatabase must have 10 decision-variable columns')
                if not np.isfinite(X).all():raise ValueError('Decision database contains non-finite values')
                mean=X.mean(axis=0);inv_cov=np.linalg.pinv(np.cov(X,rowvar=False))
            else:mean=np.zeros(10);inv_cov=np.eye(10)
            problem=RSCCProblem(props,predictor,mean,inv_cov,settings)
            # Initial population is screened by ALL constraints, including model-dependent ones.
            rng=np.random.default_rng(seed);valid=[];attempts=0;limit=max(20000,pop*500)
            while len(valid)<pop and attempts<limit and not self.stop_event.is_set():
                batch=np.minimum(256,limit-attempts)
                proposals=[]
                for _ in range(batch):
                    candidate=sample_physical_mix(rng,props['density'])
                    if candidate is None: candidate=rng.uniform(problem.xl,problem.xu)
                    proposals.append(candidate)
                X=np.asarray(proposals)
                F={};problem._evaluate(X,F);attempts+=batch
                mask=np.all(F['G']<=1e-8,axis=1)
                valid.extend(X[mask].tolist())
                if attempts%5000<batch:self.events.put(('progress',f'Initial feasible: {len(valid)}/{pop} after {attempts} proposals'))
            if self.stop_event.is_set():self.events.put(('stopped',None));return
            if len(valid)<pop:
                raise RuntimeError(f'Only {len(valid)} feasible initial candidates after {attempts} uniform proposals. '
                    'Consider relaxing bounds or providing a tailored SCC feasible sampler; no optimisation was started.')
            sampling=Population.new('X',np.asarray(valid[:pop]))
            algo=NSGA2(pop_size=pop,sampling=sampling,eliminate_duplicates=True)
            result=minimize(problem,algo,termination=('n_gen',gens),seed=seed,verbose=False,
                            callback=Stopper(self.stop_event,self.events))
            if result.X is None or len(np.atleast_2d(result.X))==0:
                raise RuntimeError('No feasible non-dominated solutions returned. Adjust settings.')
            X=np.atleast_2d(result.X);F=np.atleast_2d(result.F)
            records=[]
            for x,f in zip(X,F):
                ff,gg,masses,ratios=calculate(x,props,predictor,mean,inv_cov,settings)
                if np.any(gg>1e-7):continue
                row=dict(zip(DECISIONS,x));row.update({'Cost (AUD/m³)':ff[0],'CO2 (kg/m³)':ff[1],'CS (MPa)':-ff[2]})
                row.update({k:v for k,v in masses.items() if k not in row});row.update({'Ratio_'+k:v for k,v in ratios.items()})
                records.append(row)
            if not records:raise RuntimeError('No solutions passed independent feasibility recheck.')
            df=pd.DataFrame(records)
            output=HERE/'outputs';output.mkdir(exist_ok=True)
            df.to_csv(output/'RSCC_GUI_Pareto.csv',index=False)
            (output/'RSCC_GUI_Settings.json').write_text(json.dumps({'model':'H-GB','pop':pop,'generations':gens,'seed':seed,'settings':settings,'properties':props},indent=2),encoding='utf-8')
            self.events.put(('done',df))
        except Exception as exc:self.events.put(('error',(str(exc),traceback.format_exc())))
    def _poll(self):
        try:
            while True:
                typ,val=self.events.get_nowait()
                if typ=='progress':self.status.set(f'Running: {val}')
                elif typ=='error':
                    self.running=False
                    self.status.set('Error')
                    short_error, full_trace = val
                    log_dir=HERE/'outputs'
                    log_dir.mkdir(exist_ok=True)
                    log_path=log_dir/'RSCC_GUI_Error_Log.txt'
                    with log_path.open('a',encoding='utf-8') as log:
                        log.write('\n'+'='*72+'\n')
                        log.write(datetime.datetime.now().isoformat()+'\n')
                        log.write(full_trace+'\n')
                    messagebox.showerror('RSCC optimisation error',
                        f'{short_error}\n\nFull technical details saved to:\n{log_path}')
                elif typ=='stopped':self.running=False;self.status.set('Stopped by user')
                elif typ=='done':self.running=False;self._display(val);self.status.set(f'Completed: {len(val)} feasible Pareto solutions; saved to outputs/')
        except queue.Empty:pass
        self.root.after(150,self._poll)
    def _display(self,df):
        for row in self.tree.get_children():self.tree.delete(row)
        for _,row in df.iterrows():
            self.tree.insert('',tk.END,values=[f'{row[k]:.2f}' for k in self.table_columns])
        self.ax.clear();cs=df['CS (MPa)'].to_numpy(float)
        pts=self.ax.scatter(df['Cost (AUD/m³)'],df['CO2 (kg/m³)'],cs,c=cs,cmap='winter',s=18)
        self.ax.set_xlabel('Cost (AUD/m³)',labelpad=3);self.ax.set_ylabel('CO₂-eq (kg/m³)',labelpad=3);self.ax.set_zlabel('CS (MPa)',labelpad=3)
        self.ax.view_init(elev=23,azim=-58)
        self.ax.tick_params(axis='both', labelsize=9, pad=0)
        self.ax.set_box_aspect((1.25, 1.05, 0.85), zoom=0.88)
        self.canvas.draw_idle()
    def stop(self):
        if self.running:self.stop_event.set();self.status.set('Stop requested — waiting for current generation...')
    def reset_plot(self):
        self.ax.clear();self.ax.set_xlabel('Cost (AUD/m³)',labelpad=3);self.ax.set_ylabel('CO₂-eq (kg/m³)',labelpad=3);self.ax.set_zlabel('CS (MPa)',labelpad=3);self.ax.set_box_aspect((1.25,1.05,0.85),zoom=0.88);self.canvas.draw_idle()

if __name__=='__main__':
    root=tk.Tk();GUI(root);root.mainloop()
